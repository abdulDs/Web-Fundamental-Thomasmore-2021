This Tinder like project is made for Webfundamental course at Thomas more
the goal of the project 